/*Author: Jon Koehmstedt
11/20/2012
This program asks for a word and prints the characters individually*/

import java.util.Scanner;

public class PrintWord
{
	public static void main(String[] args)
	{
		int wordLength, i;
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("I will ask you for a word\n"
		+"then I will print each individual letter\n");
		System.out.println("Now please enter a word");
		String word = keyboard.next();
		
		wordLength = word.length();
		i=0;
		while (i < wordLength)
			{System.out.println(word.charAt(i));
			i++;}
		
	}//main
}//class


