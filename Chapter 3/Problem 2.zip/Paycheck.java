/*Author: Jon Koehmstedt
11/13/2012
This program calculates the amount an employee is supposed to be paid*/

import javax.swing.JOptionPane;

public class Paycheck
{
	public static final double SALARY = 65.45; //dollars per hour
	public static void main(String[] args)
	{
		String employee = "Dan the man";
		double hours, payment;
		
		hours = Integer.parseInt(JOptionPane.showInputDialog("Hey " + employee + "!\nHope you had a very productive week."
			+ "\n\nHow many hours did you work this week?"));
		
		if ( hours <= 40 )
		{	payment = SALARY * hours;
		}
		else
		{	payment = (SALARY * 40) + ((hours-40)*(1.5*SALARY));
		}
		
		JOptionPane.showMessageDialog(null,"Employee name: " + employee + 
		"\nHours worked this week: " + hours +
		"\nAmount to be paid for this week: $" + payment);
		
		System.exit(0);
	
	
	}//main
}//class


