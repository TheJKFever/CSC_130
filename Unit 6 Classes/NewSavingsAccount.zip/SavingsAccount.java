import java.util.Scanner;
/**
Class for Savings Account Functions
*/


public class SavingsAccount
{
	Scanner keyboard = new Scanner(System.in);
	
	public static final double CHECKBOOKCOST = 5.99;
	public static final String CARDTYPE = "ATM Card";
	public static final double OVERDRAFTCHARGE = 39.99;
	public static final double INTERESTRATE = 2.02;

	private double interest, balance=0, depositAmount;
	private double withdrawalAmount, newBalance;
	int checksAmount;
	boolean wantATMCard, onlineBanking, equals;
	private String email, address, username, password;
	
	
	public void explainAllDetails()
	{	System.out.println("By creating a Savings Account, you now are able to store your funds at our bank.\n"
		+"You will earn interest on the average monthly balance you hold in this account at the rate of: " + INTERESTRATE +"%\n"
		+"We will issue you checks at $" + CHECKBOOKCOST + " per checkbook.\n"
		+"We will issue you an " + CARDTYPE + " at no charge.\n"
		+"With this " + CARDTYPE + ", you will be able to check your balance, make withdrawals, and make deposits.\n"
		+"We also offer online banking at no charge.\n"
		+"We will send you a statement at the end of each month.\n");
	}
	
	public void explainInterest()
	{	System.out.println("As long as you have an average monthly balance of $100 or more in your account,\n"
		+"You will earn interest on the average monthly balance you hold at the rate of: " + INTERESTRATE +"%\n");
	}	

	public void explainOverdraftCharges()
	{	System.out.println("If for whatever reason, you're balance goes below zero, you will be charge overdraft charges.");
		System.out.println("You will be charged $" + OVERDRAFTCHARGE + "for every withdrawal you make that leaves your balance negative.");
		System.out.println("Additionally, you will be charged $" + OVERDRAFTCHARGE + "if your balance is negative after a month with 0 transactions.\n");
	}		
	
	public void checkbooksAmount()
	{	String answer="yes";
	Scanner keyboard2 = new Scanner(System.in);
		do {System.out.println("How many checkbooks would you like?");
				checksAmount = keyboard.nextInt();
				if (checksAmount<0)
				{	System.out.println("Please enter an amount greater or equal to 0");
				}
				else if (checksAmount>0)
				{	System.out.println("at $" + CHECKBOOKCOST + " per checkbook, that will cost $" + (CHECKBOOKCOST * checksAmount));
					System.out.println("Is that okay (yes or no)?");
					answer = keyboard2.nextLine();
				}
				else if (checksAmount==0)
				{	System.out.println("You do not want any checks.");
					System.out.println("Is that correct (yes or no)?");			
					answer = keyboard2.nextLine();
				}
			} while (!(answer.equalsIgnoreCase("yes"))||(checksAmount<0));
	}	

	public void wantOnlineBanking()
	{	String answer;
		System.out.println("With online bnaking, you are able to check your balance, make withdrawals, make deposits, and pay your bills, all from the comfort of your home.");
		do {System.out.println("Do you want to signup for online banking?");
			answer = keyboard.nextLine();
			onlineBanking=(answer.equalsIgnoreCase("yes"));
			if(onlineBanking)
			{	System.out.println("Great! Now we just need to setup a username and password");
				System.out.println("Please type in your desired username (please no spaces or special characters)");
				username = keyboard.nextLine();
				System.out.println("Please type in your desired password (please no spaces or special characters)");
				username = keyboard.nextLine();
				System.out.println("We will send you an email with your login information so you do not forget.");
				System.out.println("What is you're email address?");
				email = keyboard.nextLine();
				while (email.indexOf("@")==-1)
				{	System.out.println("Please input a valid email address.");
					System.out.println("What is you're email address?");
					email = keyboard.nextLine();
				}
				System.out.println();
			}
			else if((!(answer.equalsIgnoreCase("yes")))&&(!(answer.equalsIgnoreCase("no"))))
			{	System.out.println("Please enter either \"yes\" or \"no\"");
			}
			else 
			{	System.out.println("You can always change your mind.");
			}
		} while ((!(answer.equalsIgnoreCase("yes")))&&(!(answer.equalsIgnoreCase("no"))));
	}
	
	public void wantATMCardMethod()
	{	String answer;
		System.out.println("With this ATM card, you will be able to check your balance, make withdrawals, and make deposits.");
		do {System.out.println("Would you like an ATM card (yes or no)?");
			answer = keyboard.nextLine();
			if((!(answer.equalsIgnoreCase("yes")))&&(!(answer.equalsIgnoreCase("no"))))
			{	System.out.println("Please enter either \"yes\" or \"no\"");
			}
		} while ((!(answer.equalsIgnoreCase("yes")))&&(!(answer.equalsIgnoreCase("no"))));
		wantATMCard=(answer.equalsIgnoreCase("yes"));
	}

	public void statementDestination()
	{	Scanner keyboard2 = new Scanner(System.in);
		Scanner keyboard3 = new Scanner(System.in);
		System.out.println("Would you like this Statement sent to your address, to your email, or to both?");
		System.out.println("enter \"1\" for address, \"2\" for email, or \"3\" for both");		
		int tempNum = keyboard.nextInt();
		switch (tempNum)
		{
			case 1:
			{	if(checksAmount>0)
				{	System.out.println("Great! We will send the Statements to your house at the end of every month.");
				}
				else
				{	System.out.println("Great! We will send the Statements to your house at the end of every month.\n"
					+"What is your address?");
					address = keyboard2.nextLine();
				}
			break;
			}
			case 2:
			{	if(onlineBanking)
				{	System.out.println("Great! We will send the Statements to your email address at the end of every month.");
				}
				else
				{	System.out.println("Great! We will send the Statements to your email address at the end of every month.\n"
					+"What is your email address?");
					email = keyboard2.nextLine();
					while (email.indexOf("@")==-1)
					{	System.out.println("Please input a valid email address.");
						System.out.println("What is you're email address?");
						email = keyboard3.nextLine();
					}
				}
			break;
			}
			case 3:
			{	if((checksAmount>0)&&(onlineBanking))
				{	System.out.println("Great! We will send the Statements to both your house and your email address at the end of every month.");
				}
				else if (onlineBanking)
				{	System.out.println("Great! We will send the Statements to both your house and your email address at the end of every month.\n"
					+"What is your address?");
					address = keyboard2.nextLine();
				}
				else if (checksAmount>0)
				{	System.out.println("Great! We will send the Statements to both your house and your email address at the end of every month.\n"
					+"What is your email address?");
					email = keyboard2.nextLine();
					while (email.indexOf("@")==-1)
					{	System.out.println("Please input a valid email address.");
						System.out.println("What is you're email address?");
						email = keyboard3.nextLine();
					}
				}
				else
				{	System.out.println("Great! We will send the Statements to both your house and your email address at the end of every month.\n"
					+"What is your email address?");
					email = keyboard2.nextLine();
					while (email.indexOf("@")==-1)
					{	System.out.println("Please input a valid email address.");
						System.out.println("What is you're email address?");
						email = keyboard2.nextLine();
						System.out.println("What is your address?");
						address = keyboard3.nextLine();
					}
				}
			break;
			}
		}
	}
	
	public double initialBalance()
	{	System.out.println("How much will you be depositing to open your account?");
		balance = keyboard.nextDouble();
		while (balance<100)
			{System.out.print ("I'm sorry, but to open an account you must make an initial deposit of $100 or greater");
			System.out.println("How much will you be depositing to open your account?");
			balance = keyboard.nextDouble();
			}
		return balance;
	}

}//class SavingsAccount