import java.util.Scanner;
/**
Class for counting a number above 0
*/

public class Counter
{
	Scanner keyboard = new Scanner(System.in);
	
	private int count;
	
	/*Write the paramaters for count*/
	public void writeInput()
	{
		System.out.println("the count is: " + count);
	}	
	
	
	/*Adds one to the count*/
	public int addOne()
	{	
		count=count+1;
		return count;
	}
	
	/*Subtracts one from the variable*/
	public int minusOne()
	{	if (count<1)
			System.out.println("System cannot subtract 1, or else this number will become negative");
		else count=count-1;
		return count;		
	}
	
	
	/* sets the integer to 0*/
	public int setZero()
	{	
		count = 0;
		return count;		
	}
	
	
	public int getCount()
	{
		return count;
	}

	/*determines if two Counters are at the same number*/
	public boolean equals(Counter otherCount)
	{
		return (count==otherCount.count);
	}
	
	
}//class Count