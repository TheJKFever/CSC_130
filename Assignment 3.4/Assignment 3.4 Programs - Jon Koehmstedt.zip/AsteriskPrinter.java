/*Author: Jon Koehmstedt
Date: 11/6/12
Homework Activity 3.4 - Assignment - PART 5
This program prints out my first name in Asterisks
*/

public class AsteriskPrinter {

public static void main(String[] args) {

System.out.println("********\n********\n   **\n   **\n   **\n   **\n*  **\n*  **\n****\n **\n");    
System.out.println("  ****  \n **  **\n**    **\n**    **\n**    **\n**    **\n **  **\n  ****\n");
System.out.println("*  ***\n***  **\n**    **\n**    **\n**    **\n**    **\n**    **");
 
}//main


} //AsteriskPrinter 
