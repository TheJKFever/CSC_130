/*Author: Jon Koehmstedt
Date: 11/6/12
Homework Activity 3.4 - Assignment - Designing Programs*/

import java.util.Scanner;

public class DigitExtractor {

public static void main (String[] args){

int input=100000;

Scanner keyboard = new Scanner(System.in);
while(true) {
System.out.print("Enter a positive integer with 5 or less digits: ");
input = keyboard.nextInt();
if (input < 100000) break; 
System.out.println("Error! Please try again");
 }//while

char[] output = Integer.toString(input).toCharArray();
int i=0;
while (i<output.length) {
System.out.println(output[i]);
i++;
}//
 

}//main
}//DigitExtractor